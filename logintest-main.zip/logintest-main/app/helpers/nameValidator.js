export function nameValidator(name) {
  if (!name) return "Please fill in this field."
  return ''
}